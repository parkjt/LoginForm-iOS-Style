﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginForm_iOS_Style_
{
    public partial class Form1 : Form
    {
        int pushedTextbox = -1; // 0 ID, 1 PW

        int arrIDIndex = -1;
        int arrPWIndex = -1;

        string inputID = "";
        string inputPW = "";

        Panel[] pbIDBox;
        Panel[] pbPWBox;
        Panel[] pbKeyBox;

        string[] ilKey = new string[38];
        string[] ilKeySel = new string[38];

        public Form1()
        {
            InitializeComponent();

            #region IDBox Init
            pbIDBox = new Panel[8];
            pbIDBox[0] = pbID0;
            pbIDBox[1] = pbID1;
            pbIDBox[2] = pbID2;
            pbIDBox[3] = pbID3;
            pbIDBox[4] = pbID4;
            pbIDBox[5] = pbID5;
            pbIDBox[6] = pbID6;
            pbIDBox[7] = pbID7;
            #endregion

            #region PWDBox Init
            pbPWBox = new Panel[8];
            pbPWBox[0] = pbPW0;
            pbPWBox[1] = pbPW1;
            pbPWBox[2] = pbPW2;
            pbPWBox[3] = pbPW3;
            pbPWBox[4] = pbPW4;
            pbPWBox[5] = pbPW5;
            pbPWBox[6] = pbPW6;
            pbPWBox[7] = pbPW7;
            #endregion

            #region Key Box Init
            pbKeyBox = new Panel[38];
            pbKeyBox[0] = pbNumb0;
            pbKeyBox[1] = pbNumb1;
            pbKeyBox[2] = pbNumb2;
            pbKeyBox[3] = pbNumb3;
            pbKeyBox[4] = pbNumb4;
            pbKeyBox[5] = pbNumb5;
            pbKeyBox[6] = pbNumb6;
            pbKeyBox[7] = pbNumb7;
            pbKeyBox[8] = pbNumb8;
            pbKeyBox[9] = pbNumb9;
            pbKeyBox[10] = pbWordQ;
            pbKeyBox[11] = pbWordW;
            pbKeyBox[12] = pbWordE;
            pbKeyBox[13] = pbWordR;
            pbKeyBox[14] = pbWordT;
            pbKeyBox[15] = pbWordY;
            pbKeyBox[16] = pbWordU;
            pbKeyBox[17] = pbWordI;
            pbKeyBox[18] = pbWordO;
            pbKeyBox[19] = pbWordP;
            pbKeyBox[20] = pbWordA;
            pbKeyBox[21] = pbWordS;
            pbKeyBox[22] = pbWordD;
            pbKeyBox[23] = pbWordF;
            pbKeyBox[24] = pbWordG;
            pbKeyBox[25] = pbWordH;
            pbKeyBox[26] = pbWordJ;
            pbKeyBox[27] = pbWordK;
            pbKeyBox[28] = pbWordL;
            pbKeyBox[29] = pbWordZ;
            pbKeyBox[30] = pbWordX;
            pbKeyBox[31] = pbWordC;
            pbKeyBox[32] = pbWordV;
            pbKeyBox[33] = pbWordB;
            pbKeyBox[34] = pbWordN;
            pbKeyBox[35] = pbWordM;
            pbKeyBox[36] = pbEnter;
            pbKeyBox[37] = pbBackspace;
            #endregion

            #region No Sel Image List - 38
            ilKey[0] = @"C:\Sample\Image\Login(iOS)\key-0.png";
            ilKey[1] = @"C:\Sample\Image\Login(iOS)\key-1.png";
            ilKey[2] = @"C:\Sample\Image\Login(iOS)\key-2.png";
            ilKey[3] = @"C:\Sample\Image\Login(iOS)\key-3.png";
            ilKey[4] = @"C:\Sample\Image\Login(iOS)\key-4.png";
            ilKey[5] = @"C:\Sample\Image\Login(iOS)\key-5.png";
            ilKey[6] = @"C:\Sample\Image\Login(iOS)\key-6.png";
            ilKey[7] = @"C:\Sample\Image\Login(iOS)\key-7.png";
            ilKey[8] = @"C:\Sample\Image\Login(iOS)\key-8.png";
            ilKey[9] = @"C:\Sample\Image\Login(iOS)\key-9.png";
            ilKey[10] = @"C:\Sample\Image\Login(iOS)\key-Q.png";
            ilKey[11] = @"C:\Sample\Image\Login(iOS)\key-W.png";
            ilKey[12] = @"C:\Sample\Image\Login(iOS)\key-E.png";
            ilKey[13] = @"C:\Sample\Image\Login(iOS)\key-R.png";
            ilKey[14] = @"C:\Sample\Image\Login(iOS)\key-T.png";
            ilKey[15] = @"C:\Sample\Image\Login(iOS)\key-Y.png";
            ilKey[16] = @"C:\Sample\Image\Login(iOS)\key-U.png";
            ilKey[17] = @"C:\Sample\Image\Login(iOS)\key-I.png";
            ilKey[18] = @"C:\Sample\Image\Login(iOS)\key-O.png";
            ilKey[19] = @"C:\Sample\Image\Login(iOS)\key-P.png";
            ilKey[20] = @"C:\Sample\Image\Login(iOS)\key-A.png";
            ilKey[21] = @"C:\Sample\Image\Login(iOS)\key-S.png";
            ilKey[22] = @"C:\Sample\Image\Login(iOS)\key-D.png";
            ilKey[23] = @"C:\Sample\Image\Login(iOS)\key-F.png";
            ilKey[24] = @"C:\Sample\Image\Login(iOS)\key-G.png";
            ilKey[25] = @"C:\Sample\Image\Login(iOS)\key-H.png";
            ilKey[26] = @"C:\Sample\Image\Login(iOS)\key-J.png";
            ilKey[27] = @"C:\Sample\Image\Login(iOS)\key-K.png";
            ilKey[28] = @"C:\Sample\Image\Login(iOS)\key-L.png";
            ilKey[29] = @"C:\Sample\Image\Login(iOS)\key-Z.png";
            ilKey[30] = @"C:\Sample\Image\Login(iOS)\key-X.png";
            ilKey[31] = @"C:\Sample\Image\Login(iOS)\key-C.png";
            ilKey[32] = @"C:\Sample\Image\Login(iOS)\key-V.png";
            ilKey[33] = @"C:\Sample\Image\Login(iOS)\key-B.png";
            ilKey[34] = @"C:\Sample\Image\Login(iOS)\key-N.png";
            ilKey[35] = @"C:\Sample\Image\Login(iOS)\key-M.png";
            ilKey[36] = @"C:\Sample\Image\Login(iOS)\key-enter.png";
            ilKey[37] = @"C:\Sample\Image\Login(iOS)\key-backspace.png";
            #endregion

            #region Select Image List - 38
            ilKeySel[0] = @"C:\Sample\Image\Login(iOS)\key-0_sel.png";
            ilKeySel[1] = @"C:\Sample\Image\Login(iOS)\key-1_sel.png";
            ilKeySel[2] = @"C:\Sample\Image\Login(iOS)\key-2_sel.png";
            ilKeySel[3] = @"C:\Sample\Image\Login(iOS)\key-3_sel.png";
            ilKeySel[4] = @"C:\Sample\Image\Login(iOS)\key-4_sel.png";
            ilKeySel[5] = @"C:\Sample\Image\Login(iOS)\key-5_sel.png";
            ilKeySel[6] = @"C:\Sample\Image\Login(iOS)\key-6_sel.png";
            ilKeySel[7] = @"C:\Sample\Image\Login(iOS)\key-7_sel.png";
            ilKeySel[8] = @"C:\Sample\Image\Login(iOS)\key-8_sel.png";
            ilKeySel[9] = @"C:\Sample\Image\Login(iOS)\key-9_sel.png";
            ilKeySel[10] = @"C:\Sample\Image\Login(iOS)\key-Q_sel.png";
            ilKeySel[11] = @"C:\Sample\Image\Login(iOS)\key-W_sel.png";
            ilKeySel[12] = @"C:\Sample\Image\Login(iOS)\key-E_sel.png";
            ilKeySel[13] = @"C:\Sample\Image\Login(iOS)\key-R_sel.png";
            ilKeySel[14] = @"C:\Sample\Image\Login(iOS)\key-T_sel.png";
            ilKeySel[15] = @"C:\Sample\Image\Login(iOS)\key-Y_sel.png";
            ilKeySel[16] = @"C:\Sample\Image\Login(iOS)\key-U_sel.png";
            ilKeySel[17] = @"C:\Sample\Image\Login(iOS)\key-I_sel.png";
            ilKeySel[18] = @"C:\Sample\Image\Login(iOS)\key-O_sel.png";
            ilKeySel[19] = @"C:\Sample\Image\Login(iOS)\key-P_sel.png";
            ilKeySel[20] = @"C:\Sample\Image\Login(iOS)\key-A_sel.png";
            ilKeySel[21] = @"C:\Sample\Image\Login(iOS)\key-S_sel.png";
            ilKeySel[22] = @"C:\Sample\Image\Login(iOS)\key-D_sel.png";
            ilKeySel[23] = @"C:\Sample\Image\Login(iOS)\key-F_sel.png";
            ilKeySel[24] = @"C:\Sample\Image\Login(iOS)\key-G_sel.png";
            ilKeySel[25] = @"C:\Sample\Image\Login(iOS)\key-H_sel.png";
            ilKeySel[26] = @"C:\Sample\Image\Login(iOS)\key-J_sel.png";
            ilKeySel[27] = @"C:\Sample\Image\Login(iOS)\key-K_sel.png";
            ilKeySel[28] = @"C:\Sample\Image\Login(iOS)\key-L_sel.png";
            ilKeySel[29] = @"C:\Sample\Image\Login(iOS)\key-Z_sel.png";
            ilKeySel[30] = @"C:\Sample\Image\Login(iOS)\key-X_sel.png";
            ilKeySel[31] = @"C:\Sample\Image\Login(iOS)\key-C_sel.png";
            ilKeySel[32] = @"C:\Sample\Image\Login(iOS)\key-V_sel.png";
            ilKeySel[33] = @"C:\Sample\Image\Login(iOS)\key-B_sel.png";
            ilKeySel[34] = @"C:\Sample\Image\Login(iOS)\key-N_sel.png";
            ilKeySel[35] = @"C:\Sample\Image\Login(iOS)\key-M_sel.png";
            ilKeySel[36] = @"C:\Sample\Image\Login(iOS)\key-enter_sel.png";
            ilKeySel[37] = @"C:\Sample\Image\Login(iOS)\key-backspace_sel.png";
            #endregion
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            int tmp = 0;
            for (tmp = 0; tmp < 8; tmp++)
            {
                pbIDBox[tmp].BackgroundImage.Dispose();
                pbPWBox[tmp].BackgroundImage.Dispose();
            }

            for (tmp = 0; tmp < 38; tmp++)
                pbKeyBox[tmp].BackgroundImage.Dispose();

            GC.Collect();
        }

        private void pbTextID_MouseDown(object sender, MouseEventArgs e)
        {
            RedrawPicture(ref pbTextID, @"C:\Sample\Image\Login(iOS)\key-TextID_sel.png");
            RedrawPicture(ref pbTextPW, @"C:\Sample\Image\Login(iOS)\key-TextID.png");
            pushedTextbox = 0;
        }

        private void pbTextPW_MouseDown(object sender, MouseEventArgs e)
        {
            RedrawPicture(ref pbTextID, @"C:\Sample\Image\Login(iOS)\key-TextID.png");
            RedrawPicture(ref pbTextPW, @"C:\Sample\Image\Login(iOS)\key-TextID_sel.png");
            pushedTextbox = 1;
        }

        private void pbNo_Down(object sender, MouseEventArgs e)
        {
            int tmp = Int32.Parse(((Panel)sender).Tag.ToString());
            RedrawPicture(ref pbKeyBox[tmp], ilKeySel[tmp]);
        }

        private void pbNo_Up(object sender, MouseEventArgs e)
        {
            int tmp = Int32.Parse(((Panel)sender).Tag.ToString());
            RedrawPicture(ref pbKeyBox[tmp], ilKey[tmp]);

            inputUserInformation(tmp);
        }

        private void pbWord_Down(object sender, MouseEventArgs e)
        {
            int tmp = Int32.Parse(((Panel)sender).Tag.ToString());
            RedrawPicture(ref pbKeyBox[tmp], ilKeySel[tmp]);
        }

        private void pbWord_Up(object sender, MouseEventArgs e)
        {
            int tmp = Int32.Parse(((Panel)sender).Tag.ToString());
            RedrawPicture(ref pbKeyBox[tmp], ilKey[tmp]);

            inputUserInformation(tmp);
        }

        private void inputUserInformation(int idx)
        {
            if (pushedTextbox == -1)
                return;

            if (pushedTextbox == 0 && inputID.Length < 8)
            {
                arrIDIndex++;
                RedrawPicture(ref pbIDBox[arrIDIndex], ilKey[idx]);
                pbIDBox[arrIDIndex].Visible = true;

                inputID += pbKeyBox[idx].Name.ToString().Substring(6, 1);
            }
            else if (pushedTextbox == 1 && inputPW.Length < 8) // 비밀번호는 '*'표. 단순히 Visible만 변환
            {
                arrPWIndex++;
                pbPWBox[arrPWIndex].Visible = true;

                inputPW += pbKeyBox[idx].Name.ToString().Substring(6, 1);
            }
            else
            {
                return;
            }
        }

        private void pbEnter_Click(object sender, EventArgs e)
        {
            bool IsRight = true;

            switch (inputID) // 입력된 사용자 검증
            {
                case "WHO":
                    if (inputPW.CompareTo("") == 0)
                    {
                    }

                    break;

                case "ARE":
                    if (inputPW.CompareTo("") == 0)
                    {
                    }

                    break;

                case "YOU":
                    if (inputPW.CompareTo("") == 0)
                    {
                    }

                    break;

                default:
                    IsRight = false;
                    break;
            }

            //this.Visible = false;

            if (IsRight == true) // 창은 해제가 아닌 안보임 상태기에, 변수 초기화를 수행
            {
                pushedTextbox = -1;
                arrIDIndex = -1;
                arrPWIndex = -1;
                inputID = "";
                inputPW = "";

                for (int tmp = 0; tmp < 8; tmp++)
                {
                    pbIDBox[tmp].Visible = false;
                    pbPWBox[tmp].Visible = false;
                }
            }
        }

        private void pbBackspace_Click(object sender, EventArgs e)
        {
            if (pushedTextbox == -1)
                return;

            if (pushedTextbox == 0 && inputID.Length > 0)
            {
                pbIDBox[arrIDIndex].Visible = false;
                inputID = inputID.Remove(inputID.Length - 1, 1);
                arrIDIndex--;
            }
            else if (pushedTextbox == 1 && inputPW.Length > 0)
            {
                pbPWBox[arrPWIndex].Visible = false;
                inputPW = inputPW.Remove(inputPW.Length - 1, 1);
                arrPWIndex--;
            }
            else
            {
                return;
            }
        }

        private void RedrawPicture(ref Panel pbDispose, string btmDistribute)
        {
            pbDispose.BackgroundImage.Dispose();

            pbDispose.BackgroundImage = Image.FromFile(btmDistribute);
            GC.Collect();
        }

        private void pbEnter_MouseDown(object sender, MouseEventArgs e)
        {
            RedrawPicture(ref pbEnter, ilKeySel[36]); // 초기화 INDEX가 36
        }

        private void pbEnter_MouseUp(object sender, MouseEventArgs e)
        {
            RedrawPicture(ref pbEnter, ilKey[36]);
        }

        private void pbBackspace_MouseDown(object sender, MouseEventArgs e)
        {
            RedrawPicture(ref pbBackspace, ilKeySel[37]); // 초기화 INDEX가 37
        }

        private void pbBackspace_MouseUp(object sender, MouseEventArgs e)
        {
            RedrawPicture(ref pbBackspace, ilKey[37]);
        }
    }
}
