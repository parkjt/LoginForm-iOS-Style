﻿namespace LoginForm_iOS_Style_
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pbPW7 = new System.Windows.Forms.Panel();
            this.pbPW3 = new System.Windows.Forms.Panel();
            this.pbPW6 = new System.Windows.Forms.Panel();
            this.pbPW2 = new System.Windows.Forms.Panel();
            this.pbPW5 = new System.Windows.Forms.Panel();
            this.pbPW1 = new System.Windows.Forms.Panel();
            this.pbPW4 = new System.Windows.Forms.Panel();
            this.pbPW0 = new System.Windows.Forms.Panel();
            this.pbTextPW = new System.Windows.Forms.Panel();
            this.pbID7 = new System.Windows.Forms.Panel();
            this.pbID6 = new System.Windows.Forms.Panel();
            this.pbID5 = new System.Windows.Forms.Panel();
            this.pbID4 = new System.Windows.Forms.Panel();
            this.pbID3 = new System.Windows.Forms.Panel();
            this.pbID2 = new System.Windows.Forms.Panel();
            this.pbID1 = new System.Windows.Forms.Panel();
            this.pbID0 = new System.Windows.Forms.Panel();
            this.pbTextID = new System.Windows.Forms.Panel();
            this.pbWordZ = new System.Windows.Forms.Panel();
            this.pbWordL = new System.Windows.Forms.Panel();
            this.pbWordP = new System.Windows.Forms.Panel();
            this.pbWordK = new System.Windows.Forms.Panel();
            this.pbNumb9 = new System.Windows.Forms.Panel();
            this.pbWordO = new System.Windows.Forms.Panel();
            this.pbWordJ = new System.Windows.Forms.Panel();
            this.pbNumb8 = new System.Windows.Forms.Panel();
            this.pbWordI = new System.Windows.Forms.Panel();
            this.pbEnter = new System.Windows.Forms.Panel();
            this.pbNumb7 = new System.Windows.Forms.Panel();
            this.pbWordU = new System.Windows.Forms.Panel();
            this.pbBackspace = new System.Windows.Forms.Panel();
            this.pbNumb6 = new System.Windows.Forms.Panel();
            this.pbWordM = new System.Windows.Forms.Panel();
            this.pbWordN = new System.Windows.Forms.Panel();
            this.pbWordH = new System.Windows.Forms.Panel();
            this.pbWordB = new System.Windows.Forms.Panel();
            this.pbWordY = new System.Windows.Forms.Panel();
            this.pbWordG = new System.Windows.Forms.Panel();
            this.pbNumb5 = new System.Windows.Forms.Panel();
            this.pbWordV = new System.Windows.Forms.Panel();
            this.pbWordT = new System.Windows.Forms.Panel();
            this.pbWordF = new System.Windows.Forms.Panel();
            this.pbNumb4 = new System.Windows.Forms.Panel();
            this.pbWordC = new System.Windows.Forms.Panel();
            this.pbWordR = new System.Windows.Forms.Panel();
            this.pbWordD = new System.Windows.Forms.Panel();
            this.pbNumb3 = new System.Windows.Forms.Panel();
            this.pbWordX = new System.Windows.Forms.Panel();
            this.pbWordE = new System.Windows.Forms.Panel();
            this.pbWordS = new System.Windows.Forms.Panel();
            this.pbNumb2 = new System.Windows.Forms.Panel();
            this.pbWordA = new System.Windows.Forms.Panel();
            this.pbWordW = new System.Windows.Forms.Panel();
            this.pbWordQ = new System.Windows.Forms.Panel();
            this.pbNumb1 = new System.Windows.Forms.Panel();
            this.pbNumb0 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(6, 7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(479, 342);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pbPW7
            // 
            this.pbPW7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbPW7.BackgroundImage")));
            this.pbPW7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbPW7.Location = new System.Drawing.Point(435, 26);
            this.pbPW7.Name = "pbPW7";
            this.pbPW7.Size = new System.Drawing.Size(15, 42);
            this.pbPW7.TabIndex = 125;
            this.pbPW7.Tag = "7";
            this.pbPW7.Visible = false;
            // 
            // pbPW3
            // 
            this.pbPW3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbPW3.BackgroundImage")));
            this.pbPW3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbPW3.Location = new System.Drawing.Point(351, 26);
            this.pbPW3.Name = "pbPW3";
            this.pbPW3.Size = new System.Drawing.Size(15, 42);
            this.pbPW3.TabIndex = 116;
            this.pbPW3.Tag = "4";
            this.pbPW3.Visible = false;
            // 
            // pbPW6
            // 
            this.pbPW6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbPW6.BackgroundImage")));
            this.pbPW6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbPW6.Location = new System.Drawing.Point(414, 26);
            this.pbPW6.Name = "pbPW6";
            this.pbPW6.Size = new System.Drawing.Size(15, 42);
            this.pbPW6.TabIndex = 122;
            this.pbPW6.Tag = "6";
            this.pbPW6.Visible = false;
            // 
            // pbPW2
            // 
            this.pbPW2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbPW2.BackgroundImage")));
            this.pbPW2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbPW2.Location = new System.Drawing.Point(330, 26);
            this.pbPW2.Name = "pbPW2";
            this.pbPW2.Size = new System.Drawing.Size(15, 42);
            this.pbPW2.TabIndex = 114;
            this.pbPW2.Tag = "2";
            this.pbPW2.Visible = false;
            // 
            // pbPW5
            // 
            this.pbPW5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbPW5.BackgroundImage")));
            this.pbPW5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbPW5.Location = new System.Drawing.Point(393, 26);
            this.pbPW5.Name = "pbPW5";
            this.pbPW5.Size = new System.Drawing.Size(15, 42);
            this.pbPW5.TabIndex = 121;
            this.pbPW5.Tag = "5";
            this.pbPW5.Visible = false;
            // 
            // pbPW1
            // 
            this.pbPW1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbPW1.BackgroundImage")));
            this.pbPW1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbPW1.Location = new System.Drawing.Point(309, 26);
            this.pbPW1.Name = "pbPW1";
            this.pbPW1.Size = new System.Drawing.Size(15, 42);
            this.pbPW1.TabIndex = 112;
            this.pbPW1.Tag = "1";
            this.pbPW1.Visible = false;
            // 
            // pbPW4
            // 
            this.pbPW4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbPW4.BackgroundImage")));
            this.pbPW4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbPW4.Location = new System.Drawing.Point(372, 26);
            this.pbPW4.Name = "pbPW4";
            this.pbPW4.Size = new System.Drawing.Size(15, 42);
            this.pbPW4.TabIndex = 119;
            this.pbPW4.Tag = "0";
            this.pbPW4.Visible = false;
            // 
            // pbPW0
            // 
            this.pbPW0.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbPW0.BackgroundImage")));
            this.pbPW0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbPW0.Location = new System.Drawing.Point(288, 26);
            this.pbPW0.Name = "pbPW0";
            this.pbPW0.Size = new System.Drawing.Size(15, 42);
            this.pbPW0.TabIndex = 107;
            this.pbPW0.Tag = "0";
            this.pbPW0.Visible = false;
            // 
            // pbTextPW
            // 
            this.pbTextPW.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbTextPW.BackgroundImage")));
            this.pbTextPW.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbTextPW.Location = new System.Drawing.Point(278, 19);
            this.pbTextPW.Name = "pbTextPW";
            this.pbTextPW.Size = new System.Drawing.Size(178, 55);
            this.pbTextPW.TabIndex = 110;
            this.pbTextPW.Tag = "0";
            this.pbTextPW.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbTextPW_MouseDown);
            // 
            // pbID7
            // 
            this.pbID7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbID7.BackgroundImage")));
            this.pbID7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbID7.Location = new System.Drawing.Point(237, 26);
            this.pbID7.Name = "pbID7";
            this.pbID7.Size = new System.Drawing.Size(27, 42);
            this.pbID7.TabIndex = 105;
            this.pbID7.Tag = "7";
            this.pbID7.Visible = false;
            // 
            // pbID6
            // 
            this.pbID6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbID6.BackgroundImage")));
            this.pbID6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbID6.Location = new System.Drawing.Point(209, 26);
            this.pbID6.Name = "pbID6";
            this.pbID6.Size = new System.Drawing.Size(27, 42);
            this.pbID6.TabIndex = 104;
            this.pbID6.Tag = "6";
            this.pbID6.Visible = false;
            // 
            // pbID5
            // 
            this.pbID5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbID5.BackgroundImage")));
            this.pbID5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbID5.Location = new System.Drawing.Point(181, 26);
            this.pbID5.Name = "pbID5";
            this.pbID5.Size = new System.Drawing.Size(27, 42);
            this.pbID5.TabIndex = 103;
            this.pbID5.Tag = "5";
            this.pbID5.Visible = false;
            // 
            // pbID4
            // 
            this.pbID4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbID4.BackgroundImage")));
            this.pbID4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbID4.Location = new System.Drawing.Point(153, 26);
            this.pbID4.Name = "pbID4";
            this.pbID4.Size = new System.Drawing.Size(27, 42);
            this.pbID4.TabIndex = 102;
            this.pbID4.Tag = "4";
            this.pbID4.Visible = false;
            // 
            // pbID3
            // 
            this.pbID3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbID3.BackgroundImage")));
            this.pbID3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbID3.Location = new System.Drawing.Point(125, 26);
            this.pbID3.Name = "pbID3";
            this.pbID3.Size = new System.Drawing.Size(27, 42);
            this.pbID3.TabIndex = 106;
            this.pbID3.Tag = "3";
            this.pbID3.Visible = false;
            // 
            // pbID2
            // 
            this.pbID2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbID2.BackgroundImage")));
            this.pbID2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbID2.Location = new System.Drawing.Point(97, 26);
            this.pbID2.Name = "pbID2";
            this.pbID2.Size = new System.Drawing.Size(27, 42);
            this.pbID2.TabIndex = 101;
            this.pbID2.Tag = "2";
            this.pbID2.Visible = false;
            // 
            // pbID1
            // 
            this.pbID1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbID1.BackgroundImage")));
            this.pbID1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbID1.Location = new System.Drawing.Point(69, 26);
            this.pbID1.Name = "pbID1";
            this.pbID1.Size = new System.Drawing.Size(27, 42);
            this.pbID1.TabIndex = 100;
            this.pbID1.Tag = "1";
            this.pbID1.Visible = false;
            // 
            // pbID0
            // 
            this.pbID0.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbID0.BackgroundImage")));
            this.pbID0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbID0.Location = new System.Drawing.Point(41, 26);
            this.pbID0.Name = "pbID0";
            this.pbID0.Size = new System.Drawing.Size(27, 42);
            this.pbID0.TabIndex = 97;
            this.pbID0.Tag = "0";
            this.pbID0.Visible = false;
            // 
            // pbTextID
            // 
            this.pbTextID.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbTextID.BackgroundImage")));
            this.pbTextID.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbTextID.Location = new System.Drawing.Point(30, 19);
            this.pbTextID.Name = "pbTextID";
            this.pbTextID.Size = new System.Drawing.Size(243, 55);
            this.pbTextID.TabIndex = 99;
            this.pbTextID.Tag = "0";
            this.pbTextID.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbTextID_MouseDown);
            // 
            // pbWordZ
            // 
            this.pbWordZ.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordZ.BackgroundImage")));
            this.pbWordZ.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordZ.Location = new System.Drawing.Point(414, 208);
            this.pbWordZ.Name = "pbWordZ";
            this.pbWordZ.Size = new System.Drawing.Size(36, 54);
            this.pbWordZ.TabIndex = 152;
            this.pbWordZ.Tag = "29";
            this.pbWordZ.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordZ.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordL
            // 
            this.pbWordL.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordL.BackgroundImage")));
            this.pbWordL.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordL.Location = new System.Drawing.Point(372, 208);
            this.pbWordL.Name = "pbWordL";
            this.pbWordL.Size = new System.Drawing.Size(36, 54);
            this.pbWordL.TabIndex = 149;
            this.pbWordL.Tag = "28";
            this.pbWordL.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordL.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordP
            // 
            this.pbWordP.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordP.BackgroundImage")));
            this.pbWordP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordP.Location = new System.Drawing.Point(414, 148);
            this.pbWordP.Name = "pbWordP";
            this.pbWordP.Size = new System.Drawing.Size(36, 54);
            this.pbWordP.TabIndex = 151;
            this.pbWordP.Tag = "19";
            this.pbWordP.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordP.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordK
            // 
            this.pbWordK.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordK.BackgroundImage")));
            this.pbWordK.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordK.Location = new System.Drawing.Point(330, 208);
            this.pbWordK.Name = "pbWordK";
            this.pbWordK.Size = new System.Drawing.Size(36, 54);
            this.pbWordK.TabIndex = 146;
            this.pbWordK.Tag = "27";
            this.pbWordK.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordK.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbNumb9
            // 
            this.pbNumb9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbNumb9.BackgroundImage")));
            this.pbNumb9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbNumb9.Location = new System.Drawing.Point(414, 88);
            this.pbNumb9.Name = "pbNumb9";
            this.pbNumb9.Size = new System.Drawing.Size(36, 54);
            this.pbNumb9.TabIndex = 150;
            this.pbNumb9.Tag = "9";
            this.pbNumb9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbNumb9.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordO
            // 
            this.pbWordO.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordO.BackgroundImage")));
            this.pbWordO.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordO.Location = new System.Drawing.Point(372, 148);
            this.pbWordO.Name = "pbWordO";
            this.pbWordO.Size = new System.Drawing.Size(36, 54);
            this.pbWordO.TabIndex = 148;
            this.pbWordO.Tag = "18";
            this.pbWordO.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordO.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordJ
            // 
            this.pbWordJ.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordJ.BackgroundImage")));
            this.pbWordJ.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordJ.Location = new System.Drawing.Point(288, 208);
            this.pbWordJ.Name = "pbWordJ";
            this.pbWordJ.Size = new System.Drawing.Size(36, 54);
            this.pbWordJ.TabIndex = 143;
            this.pbWordJ.Tag = "26";
            this.pbWordJ.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordJ.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbNumb8
            // 
            this.pbNumb8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbNumb8.BackgroundImage")));
            this.pbNumb8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbNumb8.Location = new System.Drawing.Point(372, 88);
            this.pbNumb8.Name = "pbNumb8";
            this.pbNumb8.Size = new System.Drawing.Size(36, 54);
            this.pbNumb8.TabIndex = 147;
            this.pbNumb8.Tag = "8";
            this.pbNumb8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbNumb8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordI
            // 
            this.pbWordI.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordI.BackgroundImage")));
            this.pbWordI.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordI.Location = new System.Drawing.Point(330, 148);
            this.pbWordI.Name = "pbWordI";
            this.pbWordI.Size = new System.Drawing.Size(36, 54);
            this.pbWordI.TabIndex = 145;
            this.pbWordI.Tag = "17";
            this.pbWordI.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordI.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbEnter
            // 
            this.pbEnter.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbEnter.BackgroundImage")));
            this.pbEnter.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbEnter.Location = new System.Drawing.Point(288, 269);
            this.pbEnter.Name = "pbEnter";
            this.pbEnter.Size = new System.Drawing.Size(99, 55);
            this.pbEnter.TabIndex = 136;
            this.pbEnter.Tag = "36";
            this.pbEnter.Click += new System.EventHandler(this.pbEnter_Click);
            this.pbEnter.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbEnter_MouseDown);
            this.pbEnter.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbEnter_MouseUp);
            // 
            // pbNumb7
            // 
            this.pbNumb7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbNumb7.BackgroundImage")));
            this.pbNumb7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbNumb7.Location = new System.Drawing.Point(330, 88);
            this.pbNumb7.Name = "pbNumb7";
            this.pbNumb7.Size = new System.Drawing.Size(36, 54);
            this.pbNumb7.TabIndex = 144;
            this.pbNumb7.Tag = "7";
            this.pbNumb7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbNumb7.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordU
            // 
            this.pbWordU.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordU.BackgroundImage")));
            this.pbWordU.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordU.Location = new System.Drawing.Point(288, 148);
            this.pbWordU.Name = "pbWordU";
            this.pbWordU.Size = new System.Drawing.Size(36, 54);
            this.pbWordU.TabIndex = 142;
            this.pbWordU.Tag = "16";
            this.pbWordU.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordU.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbBackspace
            // 
            this.pbBackspace.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbBackspace.BackgroundImage")));
            this.pbBackspace.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbBackspace.Location = new System.Drawing.Point(401, 268);
            this.pbBackspace.Name = "pbBackspace";
            this.pbBackspace.Size = new System.Drawing.Size(49, 55);
            this.pbBackspace.TabIndex = 138;
            this.pbBackspace.Tag = "37";
            this.pbBackspace.Click += new System.EventHandler(this.pbBackspace_Click);
            this.pbBackspace.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbBackspace_MouseDown);
            this.pbBackspace.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbBackspace_MouseUp);
            // 
            // pbNumb6
            // 
            this.pbNumb6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbNumb6.BackgroundImage")));
            this.pbNumb6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbNumb6.Location = new System.Drawing.Point(288, 88);
            this.pbNumb6.Name = "pbNumb6";
            this.pbNumb6.Size = new System.Drawing.Size(36, 54);
            this.pbNumb6.TabIndex = 141;
            this.pbNumb6.Tag = "6";
            this.pbNumb6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbNumb6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordM
            // 
            this.pbWordM.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordM.BackgroundImage")));
            this.pbWordM.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordM.Location = new System.Drawing.Point(246, 269);
            this.pbWordM.Name = "pbWordM";
            this.pbWordM.Size = new System.Drawing.Size(36, 54);
            this.pbWordM.TabIndex = 137;
            this.pbWordM.Tag = "35";
            this.pbWordM.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordM.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordN
            // 
            this.pbWordN.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordN.BackgroundImage")));
            this.pbWordN.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordN.Location = new System.Drawing.Point(204, 269);
            this.pbWordN.Name = "pbWordN";
            this.pbWordN.Size = new System.Drawing.Size(36, 54);
            this.pbWordN.TabIndex = 132;
            this.pbWordN.Tag = "34";
            this.pbWordN.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordN.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordH
            // 
            this.pbWordH.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordH.BackgroundImage")));
            this.pbWordH.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordH.Location = new System.Drawing.Point(246, 208);
            this.pbWordH.Name = "pbWordH";
            this.pbWordH.Size = new System.Drawing.Size(36, 54);
            this.pbWordH.TabIndex = 140;
            this.pbWordH.Tag = "25";
            this.pbWordH.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordH.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordB
            // 
            this.pbWordB.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordB.BackgroundImage")));
            this.pbWordB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordB.Location = new System.Drawing.Point(162, 269);
            this.pbWordB.Name = "pbWordB";
            this.pbWordB.Size = new System.Drawing.Size(36, 54);
            this.pbWordB.TabIndex = 128;
            this.pbWordB.Tag = "33";
            this.pbWordB.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordB.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordY
            // 
            this.pbWordY.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordY.BackgroundImage")));
            this.pbWordY.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordY.Location = new System.Drawing.Point(246, 148);
            this.pbWordY.Name = "pbWordY";
            this.pbWordY.Size = new System.Drawing.Size(36, 54);
            this.pbWordY.TabIndex = 139;
            this.pbWordY.Tag = "15";
            this.pbWordY.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordY.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordG
            // 
            this.pbWordG.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordG.BackgroundImage")));
            this.pbWordG.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordG.Location = new System.Drawing.Point(204, 208);
            this.pbWordG.Name = "pbWordG";
            this.pbWordG.Size = new System.Drawing.Size(36, 54);
            this.pbWordG.TabIndex = 134;
            this.pbWordG.Tag = "24";
            this.pbWordG.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordG.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbNumb5
            // 
            this.pbNumb5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbNumb5.BackgroundImage")));
            this.pbNumb5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbNumb5.Location = new System.Drawing.Point(246, 88);
            this.pbNumb5.Name = "pbNumb5";
            this.pbNumb5.Size = new System.Drawing.Size(36, 54);
            this.pbNumb5.TabIndex = 135;
            this.pbNumb5.Tag = "5";
            this.pbNumb5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbNumb5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordV
            // 
            this.pbWordV.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordV.BackgroundImage")));
            this.pbWordV.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordV.Location = new System.Drawing.Point(120, 269);
            this.pbWordV.Name = "pbWordV";
            this.pbWordV.Size = new System.Drawing.Size(36, 54);
            this.pbWordV.TabIndex = 123;
            this.pbWordV.Tag = "32";
            this.pbWordV.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordV.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordT
            // 
            this.pbWordT.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordT.BackgroundImage")));
            this.pbWordT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordT.Location = new System.Drawing.Point(204, 148);
            this.pbWordT.Name = "pbWordT";
            this.pbWordT.Size = new System.Drawing.Size(36, 54);
            this.pbWordT.TabIndex = 133;
            this.pbWordT.Tag = "14";
            this.pbWordT.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordT.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordF
            // 
            this.pbWordF.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordF.BackgroundImage")));
            this.pbWordF.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordF.Location = new System.Drawing.Point(162, 208);
            this.pbWordF.Name = "pbWordF";
            this.pbWordF.Size = new System.Drawing.Size(36, 54);
            this.pbWordF.TabIndex = 130;
            this.pbWordF.Tag = "23";
            this.pbWordF.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordF.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbNumb4
            // 
            this.pbNumb4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbNumb4.BackgroundImage")));
            this.pbNumb4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbNumb4.Location = new System.Drawing.Point(204, 88);
            this.pbNumb4.Name = "pbNumb4";
            this.pbNumb4.Size = new System.Drawing.Size(36, 54);
            this.pbNumb4.TabIndex = 131;
            this.pbNumb4.Tag = "4";
            this.pbNumb4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbNumb4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordC
            // 
            this.pbWordC.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordC.BackgroundImage")));
            this.pbWordC.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordC.Location = new System.Drawing.Point(78, 269);
            this.pbWordC.Name = "pbWordC";
            this.pbWordC.Size = new System.Drawing.Size(36, 54);
            this.pbWordC.TabIndex = 115;
            this.pbWordC.Tag = "31";
            this.pbWordC.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordC.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordR
            // 
            this.pbWordR.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordR.BackgroundImage")));
            this.pbWordR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordR.Location = new System.Drawing.Point(162, 148);
            this.pbWordR.Name = "pbWordR";
            this.pbWordR.Size = new System.Drawing.Size(36, 54);
            this.pbWordR.TabIndex = 129;
            this.pbWordR.Tag = "13";
            this.pbWordR.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordR.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordD
            // 
            this.pbWordD.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordD.BackgroundImage")));
            this.pbWordD.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordD.Location = new System.Drawing.Point(120, 208);
            this.pbWordD.Name = "pbWordD";
            this.pbWordD.Size = new System.Drawing.Size(36, 54);
            this.pbWordD.TabIndex = 126;
            this.pbWordD.Tag = "22";
            this.pbWordD.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordD.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbNumb3
            // 
            this.pbNumb3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbNumb3.BackgroundImage")));
            this.pbNumb3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbNumb3.Location = new System.Drawing.Point(162, 88);
            this.pbNumb3.Name = "pbNumb3";
            this.pbNumb3.Size = new System.Drawing.Size(36, 54);
            this.pbNumb3.TabIndex = 127;
            this.pbNumb3.Tag = "3";
            this.pbNumb3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbNumb3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordX
            // 
            this.pbWordX.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordX.BackgroundImage")));
            this.pbWordX.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordX.Location = new System.Drawing.Point(36, 269);
            this.pbWordX.Name = "pbWordX";
            this.pbWordX.Size = new System.Drawing.Size(36, 54);
            this.pbWordX.TabIndex = 108;
            this.pbWordX.Tag = "30";
            this.pbWordX.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordX.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordE
            // 
            this.pbWordE.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordE.BackgroundImage")));
            this.pbWordE.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordE.Location = new System.Drawing.Point(120, 148);
            this.pbWordE.Name = "pbWordE";
            this.pbWordE.Size = new System.Drawing.Size(36, 54);
            this.pbWordE.TabIndex = 124;
            this.pbWordE.Tag = "12";
            this.pbWordE.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordE.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordS
            // 
            this.pbWordS.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordS.BackgroundImage")));
            this.pbWordS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordS.Location = new System.Drawing.Point(78, 208);
            this.pbWordS.Name = "pbWordS";
            this.pbWordS.Size = new System.Drawing.Size(36, 54);
            this.pbWordS.TabIndex = 118;
            this.pbWordS.Tag = "21";
            this.pbWordS.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordS.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbNumb2
            // 
            this.pbNumb2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbNumb2.BackgroundImage")));
            this.pbNumb2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbNumb2.Location = new System.Drawing.Point(120, 88);
            this.pbNumb2.Name = "pbNumb2";
            this.pbNumb2.Size = new System.Drawing.Size(36, 54);
            this.pbNumb2.TabIndex = 120;
            this.pbNumb2.Tag = "2";
            this.pbNumb2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbNumb2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordA
            // 
            this.pbWordA.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordA.BackgroundImage")));
            this.pbWordA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordA.Location = new System.Drawing.Point(36, 208);
            this.pbWordA.Name = "pbWordA";
            this.pbWordA.Size = new System.Drawing.Size(36, 54);
            this.pbWordA.TabIndex = 109;
            this.pbWordA.Tag = "20";
            this.pbWordA.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordA.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordW
            // 
            this.pbWordW.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordW.BackgroundImage")));
            this.pbWordW.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordW.Location = new System.Drawing.Point(78, 148);
            this.pbWordW.Name = "pbWordW";
            this.pbWordW.Size = new System.Drawing.Size(36, 54);
            this.pbWordW.TabIndex = 117;
            this.pbWordW.Tag = "11";
            this.pbWordW.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordW.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbWordQ
            // 
            this.pbWordQ.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbWordQ.BackgroundImage")));
            this.pbWordQ.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbWordQ.Location = new System.Drawing.Point(36, 148);
            this.pbWordQ.Name = "pbWordQ";
            this.pbWordQ.Size = new System.Drawing.Size(36, 54);
            this.pbWordQ.TabIndex = 111;
            this.pbWordQ.Tag = "10";
            this.pbWordQ.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbWordQ.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbNumb1
            // 
            this.pbNumb1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbNumb1.BackgroundImage")));
            this.pbNumb1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbNumb1.Location = new System.Drawing.Point(78, 88);
            this.pbNumb1.Name = "pbNumb1";
            this.pbNumb1.Size = new System.Drawing.Size(36, 54);
            this.pbNumb1.TabIndex = 113;
            this.pbNumb1.Tag = "1";
            this.pbNumb1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbNumb1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // pbNumb0
            // 
            this.pbNumb0.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbNumb0.BackgroundImage")));
            this.pbNumb0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbNumb0.Location = new System.Drawing.Point(36, 88);
            this.pbNumb0.Name = "pbNumb0";
            this.pbNumb0.Size = new System.Drawing.Size(36, 54);
            this.pbNumb0.TabIndex = 98;
            this.pbNumb0.Tag = "0";
            this.pbNumb0.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbWord_Down);
            this.pbNumb0.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbWord_Up);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(506, 367);
            this.Controls.Add(this.pbID7);
            this.Controls.Add(this.pbID6);
            this.Controls.Add(this.pbID5);
            this.Controls.Add(this.pbID4);
            this.Controls.Add(this.pbID3);
            this.Controls.Add(this.pbID2);
            this.Controls.Add(this.pbID1);
            this.Controls.Add(this.pbID0);
            this.Controls.Add(this.pbPW7);
            this.Controls.Add(this.pbPW3);
            this.Controls.Add(this.pbPW6);
            this.Controls.Add(this.pbPW2);
            this.Controls.Add(this.pbPW5);
            this.Controls.Add(this.pbPW1);
            this.Controls.Add(this.pbPW4);
            this.Controls.Add(this.pbPW0);
            this.Controls.Add(this.pbTextPW);
            this.Controls.Add(this.pbTextID);
            this.Controls.Add(this.pbWordZ);
            this.Controls.Add(this.pbWordL);
            this.Controls.Add(this.pbWordP);
            this.Controls.Add(this.pbWordK);
            this.Controls.Add(this.pbNumb9);
            this.Controls.Add(this.pbWordO);
            this.Controls.Add(this.pbWordJ);
            this.Controls.Add(this.pbNumb8);
            this.Controls.Add(this.pbWordI);
            this.Controls.Add(this.pbEnter);
            this.Controls.Add(this.pbNumb7);
            this.Controls.Add(this.pbWordU);
            this.Controls.Add(this.pbBackspace);
            this.Controls.Add(this.pbNumb6);
            this.Controls.Add(this.pbWordM);
            this.Controls.Add(this.pbWordN);
            this.Controls.Add(this.pbWordH);
            this.Controls.Add(this.pbWordB);
            this.Controls.Add(this.pbWordY);
            this.Controls.Add(this.pbWordG);
            this.Controls.Add(this.pbNumb5);
            this.Controls.Add(this.pbWordV);
            this.Controls.Add(this.pbWordT);
            this.Controls.Add(this.pbWordF);
            this.Controls.Add(this.pbNumb4);
            this.Controls.Add(this.pbWordC);
            this.Controls.Add(this.pbWordR);
            this.Controls.Add(this.pbWordD);
            this.Controls.Add(this.pbNumb3);
            this.Controls.Add(this.pbWordX);
            this.Controls.Add(this.pbWordE);
            this.Controls.Add(this.pbWordS);
            this.Controls.Add(this.pbNumb2);
            this.Controls.Add(this.pbWordA);
            this.Controls.Add(this.pbWordW);
            this.Controls.Add(this.pbWordQ);
            this.Controls.Add(this.pbNumb1);
            this.Controls.Add(this.pbNumb0);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel pbPW7;
        private System.Windows.Forms.Panel pbPW3;
        private System.Windows.Forms.Panel pbPW6;
        private System.Windows.Forms.Panel pbPW2;
        private System.Windows.Forms.Panel pbPW5;
        private System.Windows.Forms.Panel pbPW1;
        private System.Windows.Forms.Panel pbPW4;
        private System.Windows.Forms.Panel pbPW0;
        private System.Windows.Forms.Panel pbTextPW;
        private System.Windows.Forms.Panel pbID7;
        private System.Windows.Forms.Panel pbID6;
        private System.Windows.Forms.Panel pbID5;
        private System.Windows.Forms.Panel pbID4;
        private System.Windows.Forms.Panel pbID3;
        private System.Windows.Forms.Panel pbID2;
        private System.Windows.Forms.Panel pbID1;
        private System.Windows.Forms.Panel pbID0;
        private System.Windows.Forms.Panel pbTextID;
        private System.Windows.Forms.Panel pbWordZ;
        private System.Windows.Forms.Panel pbWordL;
        private System.Windows.Forms.Panel pbWordP;
        private System.Windows.Forms.Panel pbWordK;
        private System.Windows.Forms.Panel pbNumb9;
        private System.Windows.Forms.Panel pbWordO;
        private System.Windows.Forms.Panel pbWordJ;
        private System.Windows.Forms.Panel pbNumb8;
        private System.Windows.Forms.Panel pbWordI;
        private System.Windows.Forms.Panel pbEnter;
        private System.Windows.Forms.Panel pbNumb7;
        private System.Windows.Forms.Panel pbWordU;
        private System.Windows.Forms.Panel pbBackspace;
        private System.Windows.Forms.Panel pbNumb6;
        private System.Windows.Forms.Panel pbWordM;
        private System.Windows.Forms.Panel pbWordN;
        private System.Windows.Forms.Panel pbWordH;
        private System.Windows.Forms.Panel pbWordB;
        private System.Windows.Forms.Panel pbWordY;
        private System.Windows.Forms.Panel pbWordG;
        private System.Windows.Forms.Panel pbNumb5;
        private System.Windows.Forms.Panel pbWordV;
        private System.Windows.Forms.Panel pbWordT;
        private System.Windows.Forms.Panel pbWordF;
        private System.Windows.Forms.Panel pbNumb4;
        private System.Windows.Forms.Panel pbWordC;
        private System.Windows.Forms.Panel pbWordR;
        private System.Windows.Forms.Panel pbWordD;
        private System.Windows.Forms.Panel pbNumb3;
        private System.Windows.Forms.Panel pbWordX;
        private System.Windows.Forms.Panel pbWordE;
        private System.Windows.Forms.Panel pbWordS;
        private System.Windows.Forms.Panel pbNumb2;
        private System.Windows.Forms.Panel pbWordA;
        private System.Windows.Forms.Panel pbWordW;
        private System.Windows.Forms.Panel pbWordQ;
        private System.Windows.Forms.Panel pbNumb1;
        private System.Windows.Forms.Panel pbNumb0;
    }
}

